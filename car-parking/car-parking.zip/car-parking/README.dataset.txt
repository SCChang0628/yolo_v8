# car-parking > 2025-04-27 2:46am
https://universe.roboflow.com/percep/car-parking-tkird

Provided by a Roboflow user
License: CC BY 4.0

